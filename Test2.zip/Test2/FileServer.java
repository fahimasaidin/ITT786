import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

import java.io.BufferedWriter;
import java.io.FileWriter;


public class FileServer {

  public final static int SOCKET_PORT = 12345;      
  public final static String SERVER = "127.0.0.1";  // localhost
  public final static String
       FILE_TO_RECEIVED = "C:Users/NorFahima/Documents/1323.txt";  // rename file to 1_add.txt
                                                            
  public final static int FILE_SIZE = 6022386; // file size                                               

  public static void main (String [] args ) throws IOException {
    int bytesRead;
    int current = 0;
    FileOutputStream fos = null;
    BufferedOutputStream bos = null;
    Socket sock = null;
    
    BufferedWriter bw = null;
	FileWriter fw = null;
	
    try {
      sock = new Socket(SERVER, SOCKET_PORT);
      System.out.println("Connecting...");

      // receive file
      byte [] mybytearray  = new byte [FILE_SIZE];
      InputStream is = sock.getInputStream();
      fos = new FileOutputStream(FILE_TO_RECEIVED);
      bos = new BufferedOutputStream(fos);
      bytesRead = is.read(mybytearray,0,mybytearray.length);
      current = bytesRead;
      
      String content = "Coklat....\n";

		fw = new FileWriter(FILE_TO_RECEIVED);
		bw = new BufferedWriter(fw);
		bw.write(content);

		System.out.println("Done");
      
      do {
         bytesRead =
            is.read(mybytearray, current, (mybytearray.length-current));
         if(bytesRead >= 0) current += bytesRead;
      } while(bytesRead < -1);

      bos.write(mybytearray, 0 , current);
      bos.flush();
    
    }
    finally {
      if (fos != null) fos.close();
      if (bos != null) bos.close();
      if (sock != null) sock.close();
      
      if (bw != null) bw.close();
      if (fw != null) fw.close();
    }
  }

}